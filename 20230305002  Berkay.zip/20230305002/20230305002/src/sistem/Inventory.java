package system;

import products.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Inventory implements IInventory<Product> {

    private List<Product> list = new ArrayList<>();
    private Map<Integer, Product> idMap = new HashMap<>();
    private final String FILE_NAME = "products.txt";

    @Override
    public void add(Product item) {
        list.add(item);
        idMap.put(item.getId(), item);
        saveToFile();
    }

    @Override
    public void delete(int id) {
        list.removeIf(p -> p.getId() == id);
        idMap.remove(id);
        saveToFile();
    }

    @Override
    public void update(Product newItem) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == newItem.getId()) {
                list.set(i, newItem);
                break;
            }
        }
        idMap.put(newItem.getId(), newItem);
        saveToFile();
    }

    @Override
    public List<Product> listAll() {
        return list;
    }

    @Override
    public Product find(int id) {
        return idMap.get(id);
    }

    public int getLastId() {
        if (list.isEmpty()) return 0;
        return list.stream().mapToInt(Product::getId).max().orElse(0);
    }

    @Override
    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Product p : list) {
                String line = p.getType() + "," + p.getId() + "," + p.getName() + "," + p.getPrice() + "," + p.getStock();
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    String type = parts[0];
                    int id = Integer.parseInt(parts[1]);
                    String name = parts[2];
                    double price = Double.parseDouble(parts[3]);
                    int stock = Integer.parseInt(parts[4]);

                    Product p;
                    if (type.equals("Electronics")) {
                        p = new Electronics(id, name, price, stock);
                    } else {
                        p = new Food(id, name, price, stock);
                    }

                    list.add(p);
                    idMap.put(id, p);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}