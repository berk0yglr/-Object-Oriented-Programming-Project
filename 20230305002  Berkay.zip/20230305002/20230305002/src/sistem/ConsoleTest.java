package system;

import products.*;

public class ConsoleTest {
    public static void main(String[] args) {

        Inventory shop = new Inventory();

        shop.add(new Electronics(1, "Samsung TV", 20000, 5));
        shop.add(new Food(2, "Pasta", 15, 50));
        shop.add(new Electronics(3, "Laptop", 35000, 2));

        System.out.println("--- PRODUCT LIST ---");
        for (Product p : shop.listAll()) {
            System.out.println(p.toString() + " | Tax: " + p.calculateTax() + " $");
        }

        System.out.println("\n--- CRITICAL STOCK WARNING (LAMBDA) ---");
        shop.listAll().stream()
                .filter(p -> p.getStock() < 10)
                .forEach(p -> System.out.println("WARNING: " + p.getName() + " is running low!"));
    }
}