package system;

import java.util.List;

public interface IInventory<T> {
    void add(T item);
    void delete(int id);
    void update(T item);
    List<T> listAll();
    T find(int id);
    void saveToFile();
    void loadFromFile();
}