package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.stream.Collectors;

import products.*;
import system.*;

public class Main extends JFrame {

    private Inventory inventory = new Inventory();
    private int idCounter = 1;

    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtName, txtPrice, txtStock, txtId;
    private JComboBox<String> cmbType;

    public Main() {
        inventory.loadFromFile();
        idCounter = inventory.getLastId() + 1;

        setTitle("Advanced Stock Tracking System");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelInput = new JPanel(new GridLayout(6, 2, 5, 5));
        panelInput.setBorder(BorderFactory.createTitledBorder("Product Operations"));

        txtId = new JTextField();
        txtId.setEditable(false);
        txtName = new JTextField();
        txtPrice = new JTextField();
        txtStock = new JTextField();
        String[] types = {"Electronics", "Food"};
        cmbType = new JComboBox<>(types);

        panelInput.add(new JLabel("ID (Auto):"));
        panelInput.add(txtId);
        panelInput.add(new JLabel("Product Name:"));
        panelInput.add(txtName);
        panelInput.add(new JLabel("Price:"));
        panelInput.add(txtPrice);
        panelInput.add(new JLabel("Stock Qty:"));
        panelInput.add(txtStock);
        panelInput.add(new JLabel("Type:"));
        panelInput.add(cmbType);

        JPanel panelButtons = new JPanel();
        JButton btnAdd = new JButton("ADD");
        JButton btnUpdate = new JButton("UPDATE");
        JButton btnDelete = new JButton("DELETE");
        JButton btnSell = new JButton("SELL (STOCK OUT)");

        panelButtons.add(btnAdd);
        panelButtons.add(btnUpdate);
        panelButtons.add(btnDelete);
        panelButtons.add(btnSell);

        panelInput.add(new JLabel("Actions:"));
        panelInput.add(panelButtons);

        add(panelInput, BorderLayout.NORTH);

        String[] columns = {"ID", "Name", "Type", "Price", "Stock", "Tax Amount"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int id = (int) tableModel.getValueAt(selectedRow, 0);
                    Product selected = inventory.find(id);
                    if (selected != null) {
                        txtId.setText(String.valueOf(selected.getId()));
                        txtName.setText(selected.getName());
                        txtPrice.setText(String.valueOf(selected.getPrice()));
                        txtStock.setText(String.valueOf(selected.getStock()));
                        cmbType.setSelectedItem(selected instanceof Electronics ? "Electronics" : "Food");
                    }
                }
            }
        });

        JPanel panelBottom = new JPanel();
        JButton btnCritical = new JButton("CRITICAL STOCK");
        JButton btnReport = new JButton("GENERAL REPORT");
        btnCritical.setBackground(Color.ORANGE);
        btnReport.setBackground(Color.CYAN);

        panelBottom.add(btnCritical);
        panelBottom.add(btnReport);
        add(panelBottom, BorderLayout.SOUTH);

        refreshTable();

        btnAdd.addActionListener(e -> processAction("ADD"));

        btnUpdate.addActionListener(e -> {
            if(txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select a product from the table to update!");
                return;
            }
            processAction("UPDATE");
        });

        btnDelete.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int id = (int) tableModel.getValueAt(selectedRow, 0);
                inventory.delete(id);
                refreshTable();
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Select a product to delete.");
            }
        });

        btnSell.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a product to sell!");
                return;
            }

            int id = (int) tableModel.getValueAt(selectedRow, 0);
            Product product = inventory.find(id);

            String input = JOptionPane.showInputDialog("How many sold? (Current: " + product.getStock() + ")");
            if (input != null) {
                try {
                    int soldAmount = Integer.parseInt(input);
                    if (soldAmount <= product.getStock()) {
                        product.setStock(product.getStock() - soldAmount);
                        inventory.update(product);
                        refreshTable();
                        JOptionPane.showMessageDialog(this, "Sale Successful!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Error: Insufficient Stock!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Enter a valid number.");
                }
            }
        });

        btnCritical.addActionListener(e -> {
            List<String> criticalList = inventory.listAll().stream()
                    .filter(u -> u.getStock() < 10)
                    .map(Product::getName)
                    .collect(Collectors.toList());
            JOptionPane.showMessageDialog(this, "Critical Stock Items:\n" + criticalList);
        });

        btnReport.addActionListener(e -> {
            double totalValue = inventory.listAll().stream()
                    .mapToDouble(u -> u.getPrice() * u.getStock())
                    .sum();

            long productCount = inventory.listAll().stream().count();

            String mostExpensive = inventory.listAll().stream()
                    .reduce((u1, u2) -> u1.getPrice() > u2.getPrice() ? u1 : u2)
                    .map(Product::getName).orElse("None");

            String report = "--- GENERAL STATUS REPORT ---\n" +
                    "Total Product Types: " + productCount + "\n" +
                    "Most Expensive: " + mostExpensive + "\n" +
                    "Total Inventory Value: " + totalValue + " $\n";

            JOptionPane.showMessageDialog(this, report);
        });
    }

    private void processAction(String actionType) {
        try {
            String name = txtName.getText();
            double price = Double.parseDouble(txtPrice.getText());
            int stock = Integer.parseInt(txtStock.getText());
            String type = (String) cmbType.getSelectedItem();

            int id;
            if (actionType.equals("ADD")) {
                id = idCounter++;
            } else {
                id = Integer.parseInt(txtId.getText());
            }

            Product product;
            if ("Electronics".equals(type)) {
                product = new Electronics(id, name, price, stock);
            } else {
                product = new Food(id, name, price, stock);
            }

            if (actionType.equals("ADD")) {
                inventory.add(product);
            } else {
                inventory.update(product);
            }

            refreshTable();
            clearFields();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values!");
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);

        for (Product p : inventory.listAll()) {
            Object[] row = {
                    p.getId(),
                    p.getName(),
                    p.getType(),
                    p.getPrice(),
                    p.getStock(),
                    String.format("%.2f $", p.calculateTax())
            };
            tableModel.addRow(row);
        }
        tableModel.fireTableDataChanged();
        table.repaint();
    }

    private void clearFields() {
        txtId.setText("");
        txtName.setText("");
        txtPrice.setText("");
        txtStock.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}