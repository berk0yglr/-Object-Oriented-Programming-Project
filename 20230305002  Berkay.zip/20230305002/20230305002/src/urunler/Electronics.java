package products;

public class Electronics extends Product {
    public Electronics(int id, String name, double price, int stock) {
        super(id, name, price, stock);
    }

    @Override
    public double calculateTax() {
        return super.calculateTax() * 1.5;
    }

    @Override
    public String getType() {
        return "Electronics";
    }
}