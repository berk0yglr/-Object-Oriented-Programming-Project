package products;

public class Food extends Product {
    public Food(int id, String name, double price, int stock) {
        super(id, name, price, stock);
    }

    @Override
    public double calculateTax() {
        return 0.0;
    }

    @Override
    public String getType() {
        return "Food";
    }
}