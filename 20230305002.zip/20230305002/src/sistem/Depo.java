package sistem;

import urunler.Urun;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Depo<T extends Urun> implements IDepo<T> {

    private List<T> liste = new ArrayList<>();
    private Map<Integer, T> idHaritasi = new HashMap<>();

    @Override
    public void ekle(T nesne) {
        liste.add(nesne);
        idHaritasi.put(nesne.getId(), nesne);
    }

    @Override
    public void sil(int id) {
        liste.removeIf(urun -> urun.getId() == id);
        idHaritasi.remove(id);
    }

    @Override
    public void guncelle(T yeniNesne) {
        for (int i = 0; i < liste.size(); i++) {
            if (liste.get(i).getId() == yeniNesne.getId()) {
                liste.set(i, yeniNesne);
                break;
            }
        }
        idHaritasi.put(yeniNesne.getId(), yeniNesne);
    }

    @Override
    public List<T> listele() {
        return liste;
    }

    @Override
    public T bul(int id) {
        return idHaritasi.get(id);
    }
}