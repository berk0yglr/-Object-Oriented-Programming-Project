package sistem;

import java.util.List;

public interface IDepo<T> {
    void ekle(T nesne);
    void sil(int id);
    void guncelle(T nesne);
    List<T> listele();
    T bul(int id);
}