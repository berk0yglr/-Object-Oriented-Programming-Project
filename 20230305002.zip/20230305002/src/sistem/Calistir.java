package sistem;
import urunler.*;

public class Calistir {
    public static void main(String[] args) {

        Depo<Urun> dukkan = new Depo<>();


        dukkan.ekle(new Elektronik(1, "Samsung TV", 20000, 5));
        dukkan.ekle(new Gıda(2, "Makarna", 15, 50));
        dukkan.ekle(new Elektronik(3, "Laptop", 35000, 2));

        System.out.println("--- ÜRÜN LİSTESİ ---");
        for (Urun u : dukkan.listele()) {
            System.out.println(u.toString() + " | Vergi: " + u.vergiHesapla() + " TL");
        }

        System.out.println("\n--- KRİTİK STOK UYARISI (LAMBDA) ---");
        dukkan.listele().stream()
                .filter(u -> u.getStok() < 10)
                .forEach(u -> System.out.println("DİKKAT: " + u.getAd() + " bitiyor!"));
    }
}