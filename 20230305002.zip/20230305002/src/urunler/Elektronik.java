package urunler;

public class Elektronik extends Urun {
    public Elektronik(int id, String ad, double fiyat, int stok) {
        super(id, ad, fiyat, stok);
    }

    @Override
    public double vergiHesapla() {
        return super.vergiHesapla() * 1.5;
    }
}