package urunler;

public class Gıda extends Urun {
    public Gıda(int id, String ad, double fiyat, int stok) {
        super(id, ad, fiyat, stok);
    }

    @Override
    public double vergiHesapla() {
        return 0.0;
    }
}