package urunler;

public class Urun {
    private int id;
    private String ad;
    private double fiyat;
    private int stok;

    public Urun(int id, String ad, double fiyat, int stok) {
        this.id = id;
        this.ad = ad;
        this.fiyat = fiyat;
        this.stok = stok;
    }

    public double vergiHesapla() {
        return fiyat * 0.18;
    }

    public int getId() { return id; }
    public String getAd() { return ad; }

    public double getFiyat() { return fiyat; }

    public int getStok() { return stok; }

    @Override
    public String toString() {
        return ad + " (Stok: " + stok + ")";
    }

    public void setAd(String ad) { this.ad = ad; }
    public void setFiyat(double fiyat) { this.fiyat = fiyat; }
    public void setStok(int stok) { this.stok = stok; }
}