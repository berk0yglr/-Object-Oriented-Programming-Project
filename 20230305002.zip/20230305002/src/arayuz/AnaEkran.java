package arayuz;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.stream.Collectors;

import urunler.*;
import sistem.*;

public class AnaEkran extends JFrame {

    private Depo<Urun> depo = new Depo<>();
    private int idSayac = 1;

    private DefaultTableModel tabloModeli;
    private JTable tablo;
    private JTextField txtAd, txtFiyat, txtStok, txtId;
    private JComboBox<String> cmbTur;

    public AnaEkran() {
        setTitle("Gelişmiş Stok Takip Sistemi");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelGiris = new JPanel(new GridLayout(6, 2, 5, 5));
        panelGiris.setBorder(BorderFactory.createTitledBorder("Ürün İşlemleri"));

        txtId = new JTextField();
        txtId.setEditable(false);
        txtAd = new JTextField();
        txtFiyat = new JTextField();
        txtStok = new JTextField();
        String[] turler = {"Elektronik", "Gıda"};
        cmbTur = new JComboBox<>(turler);

        panelGiris.add(new JLabel("ID (Otomatik):"));
        panelGiris.add(txtId);
        panelGiris.add(new JLabel("Ürün Adı:"));
        panelGiris.add(txtAd);
        panelGiris.add(new JLabel("Fiyat:"));
        panelGiris.add(txtFiyat);
        panelGiris.add(new JLabel("Stok Adedi:"));
        panelGiris.add(txtStok);
        panelGiris.add(new JLabel("Ürün Türü:"));
        panelGiris.add(cmbTur);

        JPanel panelButonlar = new JPanel();
        JButton btnEkle = new JButton("EKLE");
        JButton btnGuncelle = new JButton("GÜNCELLE");
        JButton btnSil = new JButton("SİL");
        JButton btnStokCikis = new JButton("STOK ÇIKIŞI (SATIŞ)");

        panelButonlar.add(btnEkle);
        panelButonlar.add(btnGuncelle);
        panelButonlar.add(btnSil);
        panelButonlar.add(btnStokCikis);

        panelGiris.add(new JLabel("İşlemler:"));
        panelGiris.add(panelButonlar);

        add(panelGiris, BorderLayout.NORTH);

        String[] kolonlar = {"ID", "Ad", "Tür", "Fiyat", "Stok", "Vergi Tutarı"};
        tabloModeli = new DefaultTableModel(kolonlar, 0);
        tablo = new JTable(tabloModeli);
        add(new JScrollPane(tablo), BorderLayout.CENTER);

        tablo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int seciliSatir = tablo.getSelectedRow();
                if (seciliSatir != -1) {
                    int id = (int) tabloModeli.getValueAt(seciliSatir, 0);
                    Urun secilen = depo.bul(id);
                    if (secilen != null) {
                        txtId.setText(String.valueOf(secilen.getId()));
                        txtAd.setText(secilen.getAd());
                        txtFiyat.setText(String.valueOf(secilen.getFiyat()));
                        txtStok.setText(String.valueOf(secilen.getStok()));
                        cmbTur.setSelectedItem(secilen instanceof Elektronik ? "Elektronik" : "Gıda");
                    }
                }
            }
        });

        JPanel panelAlt = new JPanel();
        JButton btnKritik = new JButton("KRİTİK STOKLAR");
        JButton btnGenelRapor = new JButton("GENEL RAPOR OLUŞTUR");
        btnKritik.setBackground(Color.ORANGE);
        btnGenelRapor.setBackground(Color.CYAN);

        panelAlt.add(btnKritik);
        panelAlt.add(btnGenelRapor);
        add(panelAlt, BorderLayout.SOUTH);

        btnEkle.addActionListener(e -> {
            islemYap("EKLE");
        });

        btnGuncelle.addActionListener(e -> {
            if(txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Lütfen tablodan güncellenecek bir ürün seçin!");
                return;
            }
            islemYap("GUNCELLE");
        });

        btnSil.addActionListener(e -> {
            int seciliSatir = tablo.getSelectedRow();
            if (seciliSatir != -1) {
                int id = (int) tabloModeli.getValueAt(seciliSatir, 0);
                depo.sil(id);
                tabloyuGuncelle();
                alanlariTemizle();
            }
        });

        btnStokCikis.addActionListener(e -> {
            int seciliSatir = tablo.getSelectedRow();
            if (seciliSatir == -1) {
                JOptionPane.showMessageDialog(this, "Lütfen satış yapılacak ürünü seçin!");
                return;
            }

            int id = (int) tabloModeli.getValueAt(seciliSatir, 0);
            Urun urun = depo.bul(id);

            String miktarStr = JOptionPane.showInputDialog("Kaç adet satıldı? (Mevcut: " + urun.getStok() + ")");
            if (miktarStr != null) {
                try {
                    int satilanAdet = Integer.parseInt(miktarStr);
                    if (satilanAdet <= urun.getStok()) {
                        urun.setStok(urun.getStok() - satilanAdet);
                        depo.guncelle(urun);
                        tabloyuGuncelle();
                        JOptionPane.showMessageDialog(this, "Satış Başarılı!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Hata: Yetersiz Stok!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Geçerli bir sayı girin.");
                }
            }
        });

        btnKritik.addActionListener(e -> {
            List<String> kritikUrunler = depo.listele().stream()
                    .filter(u -> u.getStok() < 10)
                    .map(Urun::getAd)
                    .collect(Collectors.toList());
            JOptionPane.showMessageDialog(this, "Kritik Stoklar:\n" + kritikUrunler);
        });

        btnGenelRapor.addActionListener(e -> {
            double toplamDeger = depo.listele().stream()
                    .mapToDouble(u -> u.getFiyat() * u.getStok())
                    .sum();

            long urunSayisi = depo.listele().stream().count();

            String enPahali = depo.listele().stream()
                    .reduce((u1, u2) -> u1.getFiyat() > u2.getFiyat() ? u1 : u2)
                    .map(Urun::getAd).orElse("Yok");

            String rapor = "--- GENEL DURUM RAPORU ---\n" +
                    "Toplam Ürün Çeşidi: " + urunSayisi + "\n" +
                    "En Pahalı Ürün: " + enPahali + "\n" +
                    "Toplam Depo Değeri: " + toplamDeger + " TL\n";

            JOptionPane.showMessageDialog(this, rapor);
        });
    }

    private void islemYap(String islemTuru) {
        try {
            String ad = txtAd.getText();
            double fiyat = Double.parseDouble(txtFiyat.getText());
            int stok = Integer.parseInt(txtStok.getText());
            String tur = (String) cmbTur.getSelectedItem();

            int id;
            if (islemTuru.equals("EKLE")) {
                id = idSayac++;
            } else {
                id = Integer.parseInt(txtId.getText());
            }

            Urun urun;
            if (tur.equals("Elektronik")) {
                urun = new Elektronik(id, ad, fiyat, stok);
            } else {
                urun = new Gıda(id, ad, fiyat, stok);
            }

            if (islemTuru.equals("EKLE")) {
                depo.ekle(urun);
            } else {
                depo.guncelle(urun);
            }

            tabloyuGuncelle();
            alanlariTemizle();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Lütfen sayısal değerleri düzgün girin!");
        }
    }

    private void tabloyuGuncelle() {
        tabloModeli.setRowCount(0);
        for (Urun u : depo.listele()) {
            Object[] satir = {
                    u.getId(),
                    u.getAd(),
                    (u instanceof Elektronik) ? "Elektronik" : "Gıda",
                    u.getFiyat(),
                    u.getStok(),
                    u.vergiHesapla() + " TL"
            };
            tabloModeli.addRow(satir);
        }
    }

    private void alanlariTemizle() {
        txtId.setText("");
        txtAd.setText("");
        txtFiyat.setText("");
        txtStok.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AnaEkran().setVisible(true));
    }
}